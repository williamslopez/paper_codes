function corr(x,y)
    covariance(x,y)/sqrt(variance(x)*variance(y))
end