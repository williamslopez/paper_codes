function subproblem_joint(subproblem::Model, t::Int)
    

    
    #N=samples*0.2;

    thermal_ub = Array{Float64, 2}[
        [657 1350 36 250 250 28 529 44 255 235 386 386 145 226 131 87 204 923 923 400 100 200 169 386 28 200 272 30 168 440 400 258 258 258 64 340 1058 1058 10 197 175 206 54],
        [66 485 485 350 161 72 4 20 100 132 262 363 24 126 320 20 640],
        [13 11 32 11 347 152 150 13 15 220 220 13 15 138 347 149 149 15 102 15 168 13 13 103 136 53 66 186 50 156 171 533 323],
        [166 166]
    ]
thermal_ub_reservoir  =[13774 3630 4098 332]  
  
    thermal_lb = Array{Float64,2}[
        [520.0  1080.0  0.0  59.3  27.1  0.0  0.0  0.0  219.78  199.99  0.0  0.0  0.0  0.0  0.0  0.0  0.0  0.0  0.0  399.99  0.0  0.0  0.0  0.0  0.0  0.0  0.0  0.0  0.0  0.0  0.0  0.0  0.0  0.0  0.0  0.0  71.7  28.8  0.0  132.98  0.0  0.0  0.0],
        [0.0 0.0 0.0 210.0 0.0 27.0 0.0 9.56 25.0 79.46 147.54 228.02 0.0 49.66 105.0 5.0 0.0],
        [0.0 0.0 0.0 0.0 0.7 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 223.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 348.8 0.0],
        [0 0]
    ]
  
    
    thermal_obj = Array{Float64, 2}[
         [21.49 18.96 937.0 194.79 222.22 140.58 6.27 505.92 0.01 112.46 159.97 250.87 550.66 188.89 645.3 150.0 145.68 274.54 253.83 37.8 51.93 90.69 131.68 317.98 152.8 470.34 317.98 523.35 730.54 310.41 730.54 101.33 140.34 292.49 610.33 487.56 122.65 214.48 1047.38 0.01 329.57 197.85 733.54],
         [564.57 219.0 219.0 50.47 541.93 154.1 180.51 218.77 189.54 143.04 142.86 116.9 780.0 115.9 115.9 248.31 141.18],
         [464.64 464.64 455.13 464.64 834.35 509.86 509.86 464.64 464.64 185.09 492.29 464.64 464.64 188.15 82.34 329.37 329.37 464.64 464.64 464.64 317.19 464.64 464.64 678.03 559.39 611.57 611.56 204.43 325.67 678.03 329.2 70.16 287.83],
         [329.56 329.56]
    ]
    N_THERMAL = [43, 17, 33, 2]
   
   @assert N_THERMAL == length.(thermal_obj) == length.(thermal_lb) ==
       length.(thermal_ub)
   hydro_ub = [52506.05, 13693.91, 9165.06, 17021.89]  #  com BELO MONTE hydro_ub = [52506.05, 13693.91, 9165.06, 17021.89]
   storedEnergy_initial = [59419.3000, 5874.9000, 12859.2000, 5271.5000] # 
   storedEnergy_ub = [200717.6, 19617.2, 51806.1, 12744.9] # certo
  
   #exchange_ub =  Array{Float64, 2}[
   #    [0	        0	4700	 2500	   4000],
   #    [5625	    0	   0	    0	      0],
   #    [6300	    0	   0	    0	      0],
   #    [0  	    0	   0	    0     99999], 
   #    [99999	    0	5500    99999	      0]
   #]

   exchange_ub =  Array{Float64, 2}[
        [0	    0	4700	 2500	   4000],
        [5625	    0	   0	    0	      0],
        [6300	0	   0	    0	   6000],
        [6000	0	   0	    0     99999], 
        [99999	0	5500    99999	      0]
    ]

   

   deficit_obj = [1142.8, 2465.4, 5152.46, 5845.54] # certo
   deficit_ub = [0.05, 0.05, 0.1, 0.8];
   
   
   
    demand =  Array{Float64, 2}[
        [45515  11692  10811  6507],
        [46611  11933  10683  6564],
        [47134  12005  10727  6506],
        [46429  11478  10589  6556],
        [45622  11145  10389  6645],
        [45366  11146  10129  6669],
        [45477  11055  10157  6627],
        [46149  11051  10372  6772],
        [46336  10917  10675  6843],
        [46551  11015  10934  6815],
        [46035  11156  11004  6871],
        [45234  11297  10914  6701]
        ]   

        
       #samples =82;

       scenarios =[
           inflows(1,samples), inflows(2,samples), inflows(3,samples), inflows(4,samples)
           ]

       inflow_initial = [53442.7, 6029.9, 18154.9, 5514.4] # certo
       demanda_initial=[45515  11692  10811  6507]

       set_optimizer_attribute(subproblem, "OutputFlag", 0)
       month = t % 12 == 0 ? 12 : t % 12 

       @variable(subproblem,
           0.0 <= storedEnergy[i = 1:4] <= storedEnergy_ub[i],
           SDDP.State, initial_value = storedEnergy_initial[i])
       @variable(subproblem, 0<=z[j=1:samples]<=1, integer = true)
       @variables(subproblem, begin
           0 <= spillEnergy[i = 1:4]
           0 <= hydroGeneration[i = 1:4] <= hydro_ub[i]
           thermal_lb[i][j] <= thermal[i = 1:4, j = 1:N_THERMAL[i]] <= thermal_ub[i][j]
           0 <= exchange[i = 1:5, j = 1:5] <= exchange_ub[i][j]  
       
              
               
            inflow[i = 1:4] == inflow_initial[i]  
            demanda_es[i = 1:4] == demanda_initial[i]  
            0 <= storedEnergy_per[i=1:4];
            0 <= spill_per[i=1:4];
            0 <= thermal_per[i = 1:4];
            0 <= thermal_2[i = 1:4];
            0 <= hydroGeneration_per[i=1:4]; 
            0 <= demanda_determ[i=1:4];
            0 <= demanda_cres[i=1:4];
            0 <= demanda_es_porcen[i=1:4]; 
            v[i=1:4];
            0 <= deficit[i = 1:4, j = 1:4] <= (alpha*(demand[month][i]/12000)*t+demand[month][i]+0.1*sqrt(t)*beta/100*(alpha*(demand[month][i]/12000)*t+demand[month][i])*sqrt(2)*erfinv(2*prob-1))* deficit_ub[j]; 
            #0 <= deficit[i = 1:4, j = 1:4];
        end) 

        

        

        @stageobjective(subproblem, sum(deficit_obj[i] * sum(deficit[i, :]) for i in 1:4) +sum(thermal_obj[i][j] * thermal[i, j] for i in 1:4 for j in 1:N_THERMAL[i])) 


        @constraints(subproblem, begin
               exchange_constraint, sum(exchange[:, 5]) == sum(exchange[5, :])
               state_constraint[i = 1:4], storedEnergy[i].out + spillEnergy[i] +
               hydroGeneration[i] - storedEnergy[i].in == inflow[i] 
               #[i = 1:4, k=1:samples], sum(deficit[i, :]) <= v[i];
               [i = 1:4], storedEnergy_per[i] == (storedEnergy[i].out)*100/storedEnergy_ub[i]  
               [i = 1:4], thermal_per[i] == sum(thermal[i, j] for j in 1:N_THERMAL[i])*100/thermal_ub_reservoir[i]
               [i = 1:4], hydroGeneration_per[i] == 100*hydroGeneration[i]/hydro_ub[i]
               [i = 1:4], thermal_2[i] == sum(thermal[i, j] for j in 1:N_THERMAL[i])
               #[i = 1:4], sum_exchange[i] == sum(exchange[:, i])-sum(exchange[i, :]);
               #[i = 1:4], sum_deficit[i] == sum(deficit[i, :]);
               [i = 1:4], spill_per[i] == 100*spillEnergy[i]/storedEnergy_ub[i];
               [i = 1:4], demanda_determ[i] == 100*demand[month][i]/(hydro_ub[i]+thermal_ub_reservoir[i]);
               [i = 1:4], demanda_cres[i] == (demand[month][i]/1200)*t+demand[month][i];
               [i = 1:4], demanda_es_porcen[i] == (100*demanda_es[i])/(hydro_ub[i]+thermal_ub_reservoir[i]);
               #[i = 1:4, j = 1:4, k=1:samples], deficit[i,j] <= demandas(i,alpha,beta,samples)[t][k]*deficit_ub[j];
               [i=1:4],   hydroGeneration[i] + sum(thermal[i, j] for j in 1:N_THERMAL[i]) + sum(exchange[:, i])-sum(exchange[i, :]) + sum(deficit[i, :]) ==  v[i];
               [i=1:4, k=1:samples], v[i] + demandas(i,alpha,beta,samples)[t][k]*z[k] >= demandas(i,alpha,beta,samples)[t][k];
               sum(z)<=N;
                end)
               
                  

                if t != 1  # t=1 is handled in the @variable constructor.
                   r = t-1  #% 12 == 0 ? 12 : (t - 1) % 12
                    SDDP.parameterize(subproblem, 1:length(scenarios[1][r]))   do ω  #
       
                   for i in 1:4
                           JuMP.fix(inflow[i], scenarios[i][r][ω])                                    
                   end
                end

                

               end
   end
