using SDDP
using SpecialFunctions
using Plots, Gurobi
using CSV, DataFrames


include("./subproblem_det.jl")
include("./subproblem_joint.jl")
#include("./subproblem_det_2.jl")
include("./subproblem_estocastico.jl")
include("./subproblem_probabilistico.jl")
include("./inflows.jl")
include("./demandas.jl")

#SE = CSV.read("matrices_dados/SE.csv", DataFrame);


iter=1
#replic=50

alpha = 10
beta  = 15;
prob  = 0.9;
samples=100;
N=samples*(1-prob);

low_bound = Float64[]
low_bound_1 = Float64[]
#low_bound_2 = Float64[]

T=120;


#function main_principal()

  ##################################### MODELOS #############################
    graph=SDDP.LinearGraph(T)

    model_det = SDDP.PolicyGraph(
     subproblem_det,
     graph;
     sense = :Min,
     lower_bound = 0.0,
     optimizer = Gurobi.Optimizer,
    )

    ##########################################################
    model_est = SDDP.PolicyGraph(
      subproblem_estocastico,
      graph;
      sense = :Min,
      lower_bound = 0.0,
      optimizer = Gurobi.Optimizer,
    )
    
    model_prob = SDDP.PolicyGraph(
      subproblem_probabilistico,
      graph;
      sense = :Min,
      lower_bound = 0.0,
      optimizer = Gurobi.Optimizer,
    )
    #########################################################

   # model_est_joint = SDDP.PolicyGraph(
   #   subproblem_estocastico,
   #   graph;
   #   sense = :Min,
   #   lower_bound = 0.0,
   #   optimizer = Gurobi.Optimizer,
   # )

   # model_prob_joint = SDDP.PolicyGraph(
   #   subproblem_joint,
   #  graph;
   #   sense = :Min,
   #   lower_bound = 0.0,
   #   optimizer = Gurobi.Optimizer,
   # )

    
  ######################### TREINAMENTO DOS MODELOS ##################################### 

    SDDP.train(
      model_det,
     cut_type = SDDP.SINGLE_CUT,
     iteration_limit = iter,
    )
    SDDP.write_cuts_to_file(model_det, "cortes_trained/deter_cuts.json")


    SDDP.train(
      model_prob,
      forward_pass = SDDP.AlternativeForwardPass(model_est), 
      post_iteration_callback = SDDP.AlternativePostIterationCallback(model_est),
      cut_type = SDDP.SINGLE_CUT,
      iteration_limit = iter,
    )
    SDDP.write_cuts_to_file(model_prob, "cortes_trained/proba_cuts.json")


   # SDDP.train(
   #   model_prob_joint,
   #   forward_pass = SDDP.AlternativeForwardPass(model_est_joint), 
   #   post_iteration_callback = SDDP.AlternativePostIterationCallback(model_est_joint),
   #   duality_handler = SDDP.StrengthenedConicDuality(),
   #  cut_type = SDDP.SINGLE_CUT,
   #   iteration_limit = iter,
   # )
   #SDDP.write_cuts_to_file(model_prob, "cortes_trained/joint_cuts.json")


  ####################### SIMULAÇÃO ###########################################

    
  #simulation_det = SDDP.simulate(
  #    model_det, 
  #    replic,
  #    [:storedEnergy_per, :sum_deficit, :storedEnergy],
  #)


  #simulation_prob = SDDP.simulate(
  #  model_prob, 
  #  replic,
  #  [:storedEnergy_per, :sum_deficit],
  #)  

  ####################### FIGURAS ################################################
  
  #plot(SDDP.publication_plot(simulation_det, quantile = [0.05, 0.5, 0.95], title = "Stored volume SE") do data
  #  return data[:storedEnergy_per][1]
  #nd,
  #label = "Month",
  #ylabel = "MW-month %",
  #xlims=(0,60),
  #ylims = (0,100),
  #)
  #savefig("figures_trained/stored_det_SE")  

  #plot(SDDP.publication_plot(simulation_det, quantile = [0.05, 0.5, 0.95], title = "Stored volume SE") do data
  #  return data[:storedEnergy][1].out
  #end,
  #xlabel = "Month",
  #ylabel = "MW-month",
  #xlims=(0,60),
  #ylims = (0,100),
  #)
  #savefig("figures_trained/stored_det")

  #plot(SDDP.publication_plot(simulation_prob, quantile = [0.05, 0.5, 0.95], title = "Stored volume SE") do data
  #  return data[:storedEnergy_per][1]
  #end,
  #xlabel = "Month",
  #ylabel = "MW-month %",
  #xlims=(0,60),
  #ylims = (0,100),
  #)
  #savefig("figures_trained/stored_prob_SE") 

  #plot(SDDP.publication_plot(simulation_det, quantile = [0.05, 0.5, 0.95], title = "Deficit SE") do data
  #  return data[:sum_deficit][1]
  #end,
  #xlabel = "Month",
  #ylabel = "MW-month %",
  #xlims=(0,60),
  #ylims = (0,100),
  #)
  #savefig("figures_trained/deficit_det_SE")

  #plot(SDDP.publication_plot(simulation_prob, quantile = [0.05, 0.5, 0.95], title = "Deficit SE") do data
  #  return data[:sum_deficit][1]
  #end,
  #xlabel = "Month",
  #ylabel = "MW-month %",
  #xlims=(0,60),
  #ylims = (0,100),
  #)
  #savefig("figures_trained/deficit_prob_SE")

  open("model_det.cvs", "w") do io
    for log in model_det.most_recent_training_results.log
        push!(low_bound,log.bound);
    end  
   end
  
   open("model_prob.cvs", "w") do io
    for log in model_prob.most_recent_training_results.log
        push!(low_bound_1,log.bound);
    end  
   end


   # open("model_joint.cvs", "w") do io
  #  for log in model_prob_joint.most_recent_training_results.log
  #      push!(low_bound_2,log.bound);
  #  end  
  # end


 #plot(low_bound_2,label="SAA", linewidth=2)  

 plot(low_bound_1,label="CC", linewidth=2)

 plot!(low_bound,label="DC", title="Lower bound", linewidth=2)
 
 savefig("figures_simulation/LOWER_BOUNDS/bounds.pdf")
  
  


  println("Lower bound: ", SDDP.calculate_bound(model_det))
  println("Lower bound: ", SDDP.calculate_bound(model_prob)) 
  #println("Lower bound: ", SDDP.calculate_bound(model_prob_joint))


#end
