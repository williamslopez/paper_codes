using SDDP
using SpecialFunctions
using Plots, Gurobi
using CSV, DataFrames


include("./subproblem_det.jl")
include("./subproblem_estocastico.jl")
include("./subproblem_probabilistico.jl")
include("./inflows.jl")
include("./demandas.jl")


alpha = 10
beta  = 15;
prob  = 0.9;
samples=100;
#N=samples*(1-prob);

replic=500

graph=SDDP.LinearGraph(120)


  model_1 = SDDP.PolicyGraph(
     subproblem_estocastico,
     graph;
     sense = :Min,
     lower_bound = 0.0,
     optimizer = Gurobi.Optimizer,
    )

  model_2 = SDDP.PolicyGraph(
    subproblem_estocastico,
    graph;
    sense = :Min,
    lower_bound = 0.0,
    optimizer = Gurobi.Optimizer,
   )  


   model_3 = SDDP.PolicyGraph(
    subproblem_estocastico,
     graph;
     sense = :Min,
     lower_bound = 0.0,
     optimizer = Gurobi.Optimizer,
    )



  SDDP.read_cuts_from_file(model_1, "cortes_simulacao/deter_cuts.json")
  SDDP.read_cuts_from_file(model_2, "cortes_simulacao/proba_cuts.json")
  SDDP.read_cuts_from_file(model_3, "cortes_simulacao/joint_cuts_2.json")


  simulation_det = SDDP.simulate(
      model_1, 
      replic,
      custom_recorders = Dict{Symbol,Function}(
      :shadow_price => (subproblem) -> JuMP.dual(subproblem[:demand_constraint][1]),
      ), [:storedEnergy_per, :thermal_per, :hydroGeneration_per, :spill_per, :thermal_2, :thermal, :def, :sum_deficit, :demanda_es, :hydroGeneration, :sum_exchange], #:sum_deficit
  )


  simulation_prob = SDDP.simulate(
    model_2, 
    replic,
    custom_recorders = Dict{Symbol,Function}(
      :shadow_price => (subproblem) -> JuMP.dual(subproblem[:demand_constraint][1]),
      ),
    [:storedEnergy_per, :thermal_per, :hydroGeneration_per, :hydroGeneration, :spill_per, :sum_deficit, :def, :thermal_2, :thermal, :sum_exchange, :demanda_es],
  )  

  simulation_prob_joint = SDDP.simulate(
    model_3, 
    replic,
    custom_recorders = Dict{Symbol,Function}(
      :shadow_price => (subproblem) -> JuMP.dual(subproblem[:demand_constraint][1]),
      ),
    [:storedEnergy_per, :thermal_per, :hydroGeneration_per, :spill_per, :demanda_es_porcen, :sum_deficit, :thermal_2, :thermal, :def, :demanda_es],
  )  




  plot(SDDP.publication_plot(simulation_det, quantile = [0.05, 0.5, 0.95], title = "Stored volume SE") do data #
    return data[:storedEnergy_per][1]
  end,
  xlabel = "Month",
  ylabel = "MW-month %",
  xlims=(0,60),
  ylims = (0,100),
  )
  savefig("figures_simulation/STORED/stored_det.pdf")  

  plot(SDDP.publication_plot(simulation_prob, quantile = [0.05, 0.5, 0.95], title = "Stored volume SE") do data #
    return data[:storedEnergy_per][1]
  end,
  xlabel = "Month",
  ylabel = "MW-month %",
  xlims=(0,60),
  ylims = (0,100),
  )
  savefig("figures_simulation/STORED/stored_prob.pdf") 

  plot(SDDP.publication_plot(simulation_prob_joint, quantile = [0.05, 0.5, 0.95], title = "Stored volume SE") do data #
    return data[:storedEnergy_per][1]
  end,
  xlabel = "Month",
  ylabel = "MW-month %",
  xlims=(0,60),
  ylims = (0,100),
  )
  savefig("figures_simulation/STORED/stored_joint.pdf")

   

  plot(SDDP.publication_plot(simulation_prob, quantile = [0.05, 0.5, 0.95], title = "Thermal generation SE") do data #
    return data[:thermal_per][1]
  end,
  xlabel = "Month",
  ylabel = "MW-month %",
  xlims=(0,60),
  ylims = (0,100),
  )
  savefig("figures_simulation/THERMAL/SE/thermal_prob.pdf") 

  plot(SDDP.publication_plot(simulation_prob_joint, quantile = [0.05, 0.5, 0.95], title = "Thermal generation SE") do data #
    return data[:thermal_per][1]
  end,
  xlabel = "Month",
  ylabel = "MW-month %",
  xlims=(0,60),
  ylims = (0,100),
  )
  savefig("figures_simulation/THERMAL/SE/thermal_joint.pdf") 

  plot(SDDP.publication_plot(simulation_det, quantile = [0.05, 0.5, 0.95], title = "Thermal generation SE") do data #
    return data[:thermal_per][1]
  end,
  xlabel = "Month",
  ylabel = "MW-month %",
  xlims=(0,60),
  ylims = (0,100),
  )
  savefig("figures_simulation/THERMAL/SE/thermal_det.pdf") 

 


  plot(SDDP.publication_plot(simulation_det,  quantile = [0.05, 0.5, 0.95], title = "Shadow price SE") do data #
    return data[:shadow_price][1]
  end,
  xlabel = "Month",
  #ylabel = "MW-month",
  ylims = (0, 1400),
  xlims = (0, 60),
  )
  savefig("figures_simulation/SHADOW/shaw_det.pdf")

  plot(SDDP.publication_plot(simulation_prob,  quantile = [0.05, 0.5, 0.95], title = "Shadow price SE") do data #
    return data[:shadow_price][1]
  end,
  xlabel = "Month",
  #ylabel = "MW-month",
  ylims = (0, 1400),
  xlims = (0, 60),
  )
  savefig("figures_simulation/SHADOW/shaw_prob.pdf")



  plot(SDDP.publication_plot(simulation_prob_joint, quantile = [0.05, 0.5, 0.95], title = "Shadow price SE") do data #
    return data[:shadow_price][1]
  end,
  xlabel = "Month",
  #ylabel = "MW-month",
  xlims=(0,60),
  ylims = (0,1400),
  )
  savefig("figures_simulation/SHADOW/shaw_joint.pdf")


  plot(SDDP.publication_plot(simulation_det, quantile = [0.05, 0.5, 0.95], title = "Hydro generation SE") do data #
    return data[:hydroGeneration_per][1]
  end,
  xlabel = "Month",
  ylabel = "MW-month %",
  xlims=(0,60),
  ylims = (0,100),
  )
  savefig("figures_simulation/HYDRO/hydro_det.pdf")  

  plot(SDDP.publication_plot(simulation_prob, quantile = [0.05, 0.5, 0.95], title = "Hydro generation SE") do data #
    return data[:hydroGeneration_per][1]
  end,
  xlabel = "Month",
  ylabel = "MW-month %",
  xlims=(0,60),
  ylims = (0,100),
  )
  savefig("figures_simulation/HYDRO/hydro_prob.pdf") 

  plot(SDDP.publication_plot(simulation_prob_joint, quantile = [0.05, 0.5, 0.95], title = "Hydro generation SE") do data #
    return data[:hydroGeneration_per][1]
  end,
  xlabel = "Month",
  ylabel = "MW-month %",
  xlims=(0,60),
  ylims = (0,100),
  )
  savefig("figures_simulation/HYDRO/hydro_joint.pdf")




  plot(SDDP.publication_plot(simulation_det, quantile = [0.05, 0.5, 0.95], title = "Water spillage SE") do data #
    return data[:spill_per][1]
  end,
  xlabel = "Month",
  ylabel = "MW-month %",
  xlims=(0,60),
  ylims = (0,20),
  )
  savefig("figures_simulation/SPILL/spill_det.pdf")  

  plot(SDDP.publication_plot(simulation_prob, quantile = [0.05, 0.5, 0.95], title = "water spillage SE") do data #
    return data[:spill_per][1]
  end,
  xlabel = "Month",
  ylabel = "MW-month %",
  xlims=(0,60),
  ylims = (0,20),
  )
  savefig("figures_simulation/SPILL/spill_prob.pdf") 

  plot(SDDP.publication_plot(simulation_prob_joint, quantile = [0.05, 0.5, 0.95], title = "Water spillage SE") do data #
    return data[:spill_per][1]
  end,
  xlabel = "Month",
  ylabel = "MW-month %",
  xlims=(0,60),
  ylims = (0,20),
  )
  savefig("figures_simulation/SPILL/spill_joint.pdf")



 plot(SDDP.publication_plot(simulation_prob_joint, quantile = [0.05, 0.5, 0.95], title = "Demand SE") do data
   return data[:demanda_es_porcen][1]
 end,
 xlabel = "Month",
 ylabel = "MW-month",
 xlims=(0,60),
 #ylims = (30,65),
 # # # #ylims = (0, 205000.0), #  20000.0
 # # # layout = (1, 2),
# # # # margin_bottom = 1,
# # # # size = (500, 300),
 )
 savefig("figures_simulation/DEMANDAS/SE.pdf") 

 plot(SDDP.publication_plot(simulation_prob_joint, quantile = [0.05, 0.5, 0.95], title = "Demand S") do data
 return data[:demanda_es_porcen][2]
 end,
 xlabel = "Month",
 ylabel = "MW-month",
 xlims=(0,60),
 #ylims = (50,100),
# # # # #ylims = (0, 205000.0), #  20000.0
# # # # layout = (1, 2),
# # # # margin_bottom = 1,
# # # # size = (500, 300),
 )
 savefig("figures_simulation/DEMANDAS/S.pdf") 

 plot(SDDP.publication_plot(simulation_prob_joint, quantile = [0.05, 0.5, 0.95], title = "Demand NE") do data
 return data[:demanda_es_porcen][3]
 end,
 xlabel = "Month",
 ylabel = "MW-month",
 xlims=(0,60),
 #ylims = (25,55),
# # # # #ylims = (0, 205000.0), #  20000.0
# # # # layout = (1, 2),
# # # # margin_bottom = 1,
# # # # size = (500, 300),
 )
 savefig("figures_simulation/DEMANDAS/NE.pdf") 

 plot(SDDP.publication_plot(simulation_prob_joint, quantile = [0.05, 0.5, 0.95], title = "Demand N") do data
 return data[:demanda_es_porcen][4]
 end,
 xlabel = "Month",
 ylabel = "MW-month",
 xlims=(0,60),
 #ylims = (20,40),
# # # # #ylims = (0, 205000.0), #  20000.0
# # # # layout = (1, 2),
# # # # margin_bottom = 1,
# # # # size = (500, 300),
 )
 savefig("figures_simulation/DEMANDAS/N.pdf") 




  plot(SDDP.publication_plot(simulation_det, quantile = [0.05, 0.5, 0.95], title = "Deficit SE") do data
    return data[:sum_deficit][1]
  end,
  xlabel = "Month",
  ylabel = "MW-month %",
  xlims=(0,60),
  ylims = (0,50),
  )
  savefig("figures_simulation/DEFICIT/SE/SE_det.pdf")

  plot(SDDP.publication_plot(simulation_prob, quantile = [0.05, 0.5, 0.95], title = "Deficit SE") do data
    return data[:sum_deficit][1]
  end,
  xlabel = "Month",
  ylabel = "MW-month %",
  xlims=(0,60),
  ylims = (0,50),
  )
  savefig("figures_simulation/DEFICIT/SE/SE_prob.pdf")

  plot(SDDP.publication_plot(simulation_prob_joint, quantile = [0.05, 0.5, 0.95], title = "Deficit SE") do data
    return data[:sum_deficit][1]
  end,
  xlabel = "Month",
  ylabel = "MW-month %",
  xlims=(0,60),
  ylims = (0,50),
  )
  savefig("figures_simulation/DEFICIT/SE/SE_joint.pdf")


 
